/* ******************************************************************************
 * This file is part of Optsicom Remote Experiment System client
 * 
 * License:
 *   EPL: http://www.eclipse.org/legal/epl-v10.html
 *   See the LICENSE file in the project's top-level directory for details.
 *   
 * Contributors:
 *   Optsicom(http://www.optsicom.es), Sidelab (http://www.sidelab.es) 
 *   and others
 * **************************************************************************** */
package es.optsicom.res.client.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.eclipse.core.runtime.IProgressMonitor;

import es.optsicom.res.client.RESClientPlugin;

public class ZipCreate {
	
	private static ZipOutputStream zipOut;
	private static String ruta;
	
	public ZipCreate(){
		zipOut = null;
	}
	
	public ZipOutputStream getZos(){
		return zipOut;
	}
	
	public String setidJob() {
		//Asignacion del id de trabajo cuando comienza la ejecucion
		Calendar calendar = Calendar.getInstance();
		SimpleDateFormat formato = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss");
		String cadenaFecha = formato.format(calendar.getTime());
		
		return cadenaFecha;
	}
	
	
	public String inicializar(String nombreWorkspace,String nombreProyecto) throws ZipCreationException{
		String nombre = nombreWorkspace+File.separator;//+nombreProyecto+File.separator;
		ruta = nombre;
		String nombreZip = nombreProyecto+"_"+setidJob()+".zip";
		File zipFile = new File(nombre+nombreProyecto + File.separator + nombreZip);
		try {
			zipFile.createNewFile();
			OutputStream fileOut = new FileOutputStream(zipFile);
    		zipOut = new ZipOutputStream(fileOut);
		} catch (IOException e) {
			throw new ZipCreationException(e);
		}
		//return zipFile.getPath().toString();
		return nombreZip;
	}

    public void zip(File[] files, IProgressMonitor monitor){
    	try {
			for(File file: files){
				monitor.subTask(file.getAbsolutePath());
				writeToZip(file, zipOut);
				zipOut.flush();
				monitor.worked(1);
			}
		} catch (FileNotFoundException e) {
			RESClientPlugin.log(e);
		} catch (IOException e) {
			RESClientPlugin.log(e);
		}
    }
    
    
        
    private void writeToZip(File file, ZipOutputStream zipOut) throws IOException,FileNotFoundException{
	    
	    if(file.isDirectory()){
	    	for(File child: file.listFiles()){
	    		writeToZip(child, zipOut);
	    	}
	    }
	    else{
	        
 		    String pathRelativo = file.getAbsolutePath();
	    	pathRelativo = pathRelativo.substring(ruta.length());

			ZipEntry entry = new ZipEntry(pathRelativo);
			try{
				zipOut.putNextEntry(entry);
				
				// Copy contents
		    	FileInputStream fileIn = new FileInputStream(file);
		    	copyInputStream(fileIn, zipOut);
				zipOut.flush();	
				fileIn.close();
		    } catch(Exception e){
 		    	RESClientPlugin.log(e);
 		    }
	    }   
    }
    
    /*
     * The streams are not closed. It is the user responsibility to close them
     */
	private final void copyInputStream(InputStream in, OutputStream out) throws IOException {
	    byte[] buffer = new byte[1024];
	    int len;

	    while((len = in.read(buffer)) >= 0) {
	      out.write(buffer, 0, len);
	    }
	}
    
    public void endZip(){
    	try{
    		zipOut.close();
    	} catch (IOException e){
    		RESClientPlugin.log(e);
    	}
    }
    
}
